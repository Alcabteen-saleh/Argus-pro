# =============================================================================
# Intellectual Property Notice
# -----------------------------------------------------------------------------
# This project and its source code are the exclusive intellectual property of
# Saleh Ali. All rights reserved.
#
# Unauthorized modification, reproduction, redistribution, reverse engineering,
# or creation of derivative works is strictly prohibited without prior written
# approval from Saleh Ali.
#
# For full license and disclaimer details, please refer to the LICENSE.md and
# DISCLAIMER.md files in the project root.
# =============================================================================

import os
import sys
import json
import asyncio
import subprocess
import logging
from typing import Dict, List, Optional
from datetime import datetime

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("ArgusCore")

class ModuleRunner:
    def __init__(self, modules_dir: str):
        self.modules_dir = modules_dir

    async def execute(self, module_name: str, target: str, options: Dict = None) -> Dict:
        """
        Executes a module securely and returns the results.
        """
        script_path = os.path.join(self.modules_dir, f"{module_name}.py")
        if not os.path.exists(script_path):
            raise FileNotFoundError(f"Module {module_name} not found at {script_path}")

        # Clean target first
        target = self._clean_target(target)

        # Secure input validation
        if not self._validate_target(target):
            raise ValueError("Invalid target format")

        cmd = [sys.executable, script_path, target]
        if options:
            cmd.append(json.dumps(options))

        try:
            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await process.communicate()
            
            # Use 'replace' to handle encoding errors gracefully
            output_text = stdout.decode('utf-8', errors='replace').strip()
            error_text = stderr.decode('utf-8', errors='replace').strip()

            return {
                "module": module_name,
                "target": target,
                "status": "SUCCESS" if process.returncode == 0 else "FAILED",
                "output": output_text,
                "error": error_text,
                "timestamp": datetime.utcnow().isoformat()
            }
        except Exception as e:
            logger.error(f"Error executing module {module_name}: {str(e)}")
            return {
                "module": module_name,
                "target": target,
                "status": "ERROR",
                "error": str(e),
                "timestamp": datetime.utcnow().isoformat()
            }

    def _clean_target(self, target: str) -> str:
        """
        Cleans the target input by removing protocol and paths.
        """
        import re
        # Remove http:// or https://
        target = re.sub(r'^https?://', '', target)
        # Remove trailing slash and path
        target = target.split('/')[0]
        # Remove port if present
        target = target.split(':')[0]
        return target

    def _validate_target(self, target: str) -> bool:
        # Simple domain/IP validation to prevent injection
        import re
        domain_pattern = r"^(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,6}$"
        ip_pattern = r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$"
        return bool(re.match(domain_pattern, target) or re.match(ip_pattern, target))

runner = ModuleRunner(os.path.join(os.path.dirname(__file__), "modules"))
