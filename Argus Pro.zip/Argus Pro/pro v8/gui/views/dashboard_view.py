# =============================================================================
# Intellectual Property Notice
# -----------------------------------------------------------------------------
# This project and its source code are the exclusive intellectual property of
# Saleh Ali. All rights reserved.
#
# Unauthorized modification, reproduction, redistribution, reverse engineering,
# or creation of derivative works is strictly prohibited without prior written
# approval from Saleh Ali.
#
# For full license and disclaimer details, please refer to the LICENSE.md and
# DISCLAIMER.md files in the project root.
# =============================================================================

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame, QGridLayout
)
from PySide6.QtCore import Qt

class StatCard(QFrame):
    def __init__(self, title, value, color="#3b82f6"):
        super().__init__()
        self.setStyleSheet(f"""
            QFrame {{
                background-color: #1e293b;
                border-radius: 10px;
                border: 1px solid #334155;
                padding: 20px;
            }}
        """)
        layout = QVBoxLayout(self)
        
        title_label = QLabel(title)
        title_label.setStyleSheet("color: #94a3b8; font-size: 14px;")
        
        value_label = QLabel(str(value))
        value_label.setStyleSheet(f"color: {color}; font-size: 32px; font-weight: bold;")
        
        layout.addWidget(title_label)
        layout.addWidget(value_label)

class DashboardView(QWidget):
    def __init__(self):
        super().__init__()
        self.setup_ui()

    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)

        header = QLabel("Dashboard Overview")
        header.setStyleSheet("color: white; font-size: 24px; font-weight: bold; margin-bottom: 20px;")
        layout.addWidget(header)

        # Stats Grid
        stats_layout = QGridLayout()
        stats_layout.addWidget(StatCard("Total Scans", "124", "#3b82f6"), 0, 0)
        stats_layout.addWidget(StatCard("Active Modules", "108", "#10b981"), 0, 1)
        stats_layout.addWidget(StatCard("Vulnerabilities Found", "12", "#ef4444"), 0, 2)
        stats_layout.addWidget(StatCard("System Status", "Secure", "#f59e0b"), 0, 3)
        layout.addLayout(stats_layout)

        # Placeholder for Charts
        charts_frame = QFrame()
        charts_frame.setStyleSheet("background-color: #1e293b; border-radius: 10px; border: 1px solid #334155; margin-top: 20px;")
        charts_layout = QVBoxLayout(charts_frame)
        charts_label = QLabel("Activity Chart (Integration with Plotly/Matplotlib)")
        charts_label.setStyleSheet("color: #64748b;")
        charts_label.setAlignment(Qt.AlignCenter)
        charts_layout.addWidget(charts_label)
        charts_frame.setFixedHeight(300)
        layout.addWidget(charts_frame)

        layout.addStretch()
