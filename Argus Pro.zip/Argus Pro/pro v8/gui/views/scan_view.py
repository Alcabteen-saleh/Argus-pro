# =============================================================================
# Intellectual Property Notice
# -----------------------------------------------------------------------------
# This project and its source code are the exclusive intellectual property of
# Saleh Ali. All rights reserved.
#
# Unauthorized modification, reproduction, redistribution, reverse engineering,
# or creation of derivative works is strictly prohibited without prior written
# approval from Saleh Ali.
#
# For full license and disclaimer details, please refer to the LICENSE.md and
# DISCLAIMER.md files in the project root.
# =============================================================================

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLineEdit, 
    QPushButton, QComboBox, QTextEdit, QLabel, QGroupBox
)
from PySide6.QtCore import Qt, QThread, Signal
import requests
import json

class ScanWorker(QThread):
    finished = Signal(dict)
    error = Signal(str)

    def __init__(self, target, module):
        super().__init__()
        self.target = target
        self.module = module

    def run(self):
        try:
            response = requests.post(
                "http://127.0.0.1:8000/api/v1/scan",
                params={"target": self.target, "module": self.module},
                timeout=120
            )
            if response.status_code == 200:
                self.finished.emit(response.json())
            else:
                self.error.emit(f"Error: {response.text}")
        except Exception as e:
            self.error.emit(str(e))

class ScanView(QWidget):
    def __init__(self):
        super().__init__()
        self.setup_ui()
        self.load_modules()

    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)

        header = QLabel("Security Scanner")
        header.setStyleSheet("color: white; font-size: 24px; font-weight: bold; margin-bottom: 10px;")
        layout.addWidget(header)

        # Input Group
        input_group = QGroupBox("Scan Configuration")
        input_group.setStyleSheet("QGroupBox { color: #94a3b8; border: 1px solid #334155; margin-top: 10px; padding-top: 10px; }")
        input_layout = QVBoxLayout(input_group)

        target_layout = QHBoxLayout()
        self.target_input = QLineEdit()
        self.target_input.setPlaceholderText("Enter target (e.g., google.com or 8.8.8.8)")
        self.target_input.setStyleSheet("background-color: #1e293b; color: white; padding: 10px; border-radius: 5px;")
        
        self.module_combo = QComboBox()
        self.module_combo.setStyleSheet("background-color: #1e293b; color: white; padding: 10px; border-radius: 5px;")
        
        self.scan_btn = QPushButton("Start Scan")
        self.scan_btn.setStyleSheet("background-color: #3b82f6; color: white; padding: 10px 20px; font-weight: bold; border-radius: 5px;")
        self.scan_btn.clicked.connect(self.start_scan)

        target_layout.addWidget(self.target_input, 3)
        target_layout.addWidget(self.module_combo, 2)
        target_layout.addWidget(self.scan_btn, 1)
        input_layout.addLayout(target_layout)
        layout.addWidget(input_group)

        # Results Area
        results_label = QLabel("Scan Output")
        results_label.setStyleSheet("color: #94a3b8; margin-top: 20px;")
        layout.addWidget(results_label)

        self.output_area = QTextEdit()
        self.output_area.setReadOnly(True)
        self.output_area.setStyleSheet("background-color: #020617; color: #10b981; font-family: 'Consolas', monospace; padding: 10px; border: 1px solid #334155;")
        layout.addWidget(self.output_area)

    def load_modules(self):
        try:
            response = requests.get("http://127.0.0.1:8000/api/v1/modules")
            if response.status_code == 200:
                modules = response.json().get("modules", [])
                self.module_combo.addItems(sorted(modules))
        except:
            self.module_combo.addItem("dns_records") # Fallback

    def start_scan(self):
        target = self.target_input.text()
        module = self.module_combo.currentText()
        if not target:
            self.output_area.setText("Please enter a target.")
            return

        self.scan_btn.setEnabled(False)
        self.output_area.setText(f"[*] Starting scan on {target} using {module}...\n")
        
        self.worker = ScanWorker(target, module)
        self.worker.finished.connect(self.on_scan_finished)
        self.worker.error.connect(self.on_scan_error)
        self.worker.start()

    def on_scan_finished(self, result):
        self.scan_btn.setEnabled(True)
        self.output_area.append(f"[+] Scan Completed with status: {result.get('status')}\n")
        self.output_area.append("-" * 50 + "\n")
        self.output_area.append(result.get("output", ""))
        if result.get("error"):
            self.output_area.append("\nErrors:\n" + result.get("error"))

    def on_scan_error(self, error_msg):
        self.scan_btn.setEnabled(True)
        self.output_area.append(f"\n[!] Error: {error_msg}")
