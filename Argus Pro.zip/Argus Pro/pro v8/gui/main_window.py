# =============================================================================
# Intellectual Property Notice
# -----------------------------------------------------------------------------
# This project and its source code are the exclusive intellectual property of
# Saleh Ali. All rights reserved.
#
# Unauthorized modification, reproduction, redistribution, reverse engineering,
# or creation of derivative works is strictly prohibited without prior written
# approval from Saleh Ali.
#
# For full license and disclaimer details, please refer to the LICENSE.md and
# DISCLAIMER.md files in the project root.
# =============================================================================

import sys
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, 
    QPushButton, QLabel, QStackedWidget, QFrame,
    QListWidget, QListWidgetItem, QGraphicsDropShadowEffect
)
from PySide6.QtCore import Qt, QSize
from PySide6.QtGui import QColor, QIcon, QFont
try:
    from gui.views.dashboard_view import DashboardView
    from gui.views.scan_view import ScanView
except ImportError:
    from views.dashboard_view import DashboardView
    from views.scan_view import ScanView

class SidebarItem(QListWidgetItem):
    def __init__(self, text, icon_path=None):
        super().__init__(text)
        if icon_path:
            self.setIcon(QIcon(icon_path))
        self.setFont(QFont("Segoe UI", 10))
        self.setTextAlignment(Qt.AlignLeft | Qt.AlignVCenter)

class ArgusMainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Argus Pro - Security Platform")
        self.resize(1200, 800)
        self.setMinimumSize(1000, 700)
        
        # Apply Modern Dark Theme
        self.setStyleSheet("""
            QMainWindow {
                background-color: #0f172a;
            }
            QFrame#Sidebar {
                background-color: #1e293b;
                border-right: 1px solid #334155;
            }
            QListWidget {
                background-color: transparent;
                border: none;
                color: #94a3b8;
                outline: none;
            }
            QListWidget::item {
                padding: 15px;
                border-radius: 8px;
                margin: 5px 10px;
            }
            QListWidget::item:selected {
                background-color: #3b82f6;
                color: white;
            }
            QListWidget::item:hover:!selected {
                background-color: #334155;
                color: #f8fafc;
            }
            QLabel#Logo {
                color: #3b82f6;
                font-size: 24px;
                font-weight: bold;
                padding: 20px;
            }
            QWidget#MainContent {
                background-color: #0f172a;
            }
        """)

        self.setup_ui()

    def setup_ui(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        main_layout = QHBoxLayout(central_widget)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # Sidebar
        sidebar = QFrame()
        sidebar.setObjectName("Sidebar")
        sidebar.setFixedWidth(250)
        sidebar_layout = QVBoxLayout(sidebar)
        
        logo = QLabel("ARGUS PRO")
        logo.setObjectName("Logo")
        logo.setAlignment(Qt.AlignCenter)
        sidebar_layout.addWidget(logo)

        self.menu_list = QListWidget()
        self.menu_list.addItem(SidebarItem("Dashboard"))
        self.menu_list.addItem(SidebarItem("Security Scan"))
        self.menu_list.addItem(SidebarItem("Network Tools"))
        self.menu_list.addItem(SidebarItem("Reports"))
        self.menu_list.addItem(SidebarItem("User Management"))
        self.menu_list.addItem(SidebarItem("Settings"))
        
        sidebar_layout.addWidget(self.menu_list)
        sidebar_layout.addStretch()
        
        version_label = QLabel("v2.0.0 Professional")
        version_label.setStyleSheet("color: #64748b; font-size: 10px; padding: 10px;")
        version_label.setAlignment(Qt.AlignCenter)
        sidebar_layout.addWidget(version_label)

        # Main Content Area
        self.content_stack = QStackedWidget()
        self.content_stack.setObjectName("MainContent")
        
        # Add real views
        self.content_stack.addWidget(DashboardView())
        self.content_stack.addWidget(ScanView())
        self.content_stack.addWidget(self.create_placeholder("Network Tools View"))
        self.content_stack.addWidget(self.create_placeholder("Reports View"))
        self.content_stack.addWidget(self.create_placeholder("User Management View"))
        self.content_stack.addWidget(self.create_placeholder("Settings View"))
        
        main_layout.addWidget(sidebar)
        main_layout.addWidget(self.content_stack)

        # Connect signals
        self.menu_list.currentRowChanged.connect(self.content_stack.setCurrentIndex)

    def create_placeholder(self, text):
        widget = QWidget()
        layout = QVBoxLayout(widget)
        label = QLabel(text)
        label.setStyleSheet("color: white; font-size: 32px;")
        label.setAlignment(Qt.AlignCenter)
        layout.addWidget(label)
        return widget

if __name__ == "__main__":
    from PySide6.QtWidgets import QApplication
    app = QApplication(sys.argv)
    window = ArgusMainWindow()
    window.show()
    sys.exit(app.exec())
