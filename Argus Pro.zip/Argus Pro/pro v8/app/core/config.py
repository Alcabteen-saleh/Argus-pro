# =============================================================================
# Intellectual Property Notice
# -----------------------------------------------------------------------------
# This project and its source code are the exclusive intellectual property of
# Saleh Ali. All rights reserved.
#
# Unauthorized modification, reproduction, redistribution, reverse engineering,
# or creation of derivative works is strictly prohibited without prior written
# approval from Saleh Ali.
#
# For full license and disclaimer details, please refer to the LICENSE.md and
# DISCLAIMER.md files in the project root.
# =============================================================================

import os
from pydantic_settings import BaseSettings
from typing import List

class Settings(BaseSettings):
    PROJECT_NAME: str = "Argus Pro"
    API_V1_STR: str = "/api/v1"
    SECRET_KEY: str = os.getenv("SECRET_KEY", "SUPER_SECRET_KEY_FOR_JWT_CHANGE_IN_PRODUCTION")
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24 * 7  # 7 days
    
    # Database
    POSTGRES_SERVER: str = os.getenv("POSTGRES_SERVER", "localhost")
    POSTGRES_USER: str = os.getenv("POSTGRES_USER", "postgres")
    POSTGRES_PASSWORD: str = os.getenv("POSTGRES_PASSWORD", "postgres")
    POSTGRES_DB: str = os.getenv("POSTGRES_DB", "argus_db")
    SQLALCHEMY_DATABASE_URI: str = os.getenv("DATABASE_URL", "sqlite:///./argus_pro.db")

    # Logging
    LOG_LEVEL: str = "INFO"
    LOG_FORMAT: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    
    # Paths
    BASE_DIR: str = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    MODULES_DIR: str = os.path.join(BASE_DIR, "core", "modules")
    RESULTS_DIR: str = os.path.join(BASE_DIR, "results")
    LOGS_DIR: str = os.path.join(BASE_DIR, "logs")

    class Config:
        case_sensitive = True
        env_file = ".env"

settings = Settings()
