# =============================================================================
# Intellectual Property Notice
# -----------------------------------------------------------------------------
# This project and its source code are the exclusive intellectual property of
# Saleh Ali. All rights reserved.
#
# Unauthorized modification, reproduction, redistribution, reverse engineering,
# or creation of derivative works is strictly prohibited without prior written
# approval from Saleh Ali.
#
# For full license and disclaimer details, please refer to the LICENSE.md and
# DISCLAIMER.md files in the project root.
# =============================================================================

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from app.db.session import get_db
from app.models import base_models as models
from core.runner import runner
import asyncio
import os

router = APIRouter()

@router.get("/modules")
def list_modules():
    modules = []
    modules_dir = runner.modules_dir
    for f in os.listdir(modules_dir):
        if f.endswith(".py") and not f.startswith("__"):
            modules.append(f.replace(".py", ""))
    return {"modules": modules}

@router.post("/scan")
async def start_scan(target: str, module: str, db: Session = Depends(get_db)):
    try:
        # Check if module exists in runner's directory
        module_path = os.path.join(runner.modules_dir, f"{module}.py")
        if not os.path.exists(module_path):
            raise HTTPException(status_code=404, detail=f"Module {module} not found")
            
        result = await runner.execute(module, target)
        # Save to DB
        db_result = models.ScanResult(
            target=target,
            module_name=module,
            status=result["status"],
            raw_output=result.get("output", "") + "\n" + result.get("error", ""),
            severity="INFO"
        )
        db.add(db_result)
        db.commit()
        return result
    except Exception as e:
        import logging
        logging.error(f"Scan error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/results", response_model=List[dict])
def get_results(db: Session = Depends(get_db)):
    results = db.query(models.ScanResult).all()
    return [{"id": r.id, "target": r.target, "module": r.module_name, "status": r.status} for r in results]
