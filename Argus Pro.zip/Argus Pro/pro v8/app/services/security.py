# =============================================================================
# Intellectual Property Notice
# -----------------------------------------------------------------------------
# This project and its source code are the exclusive intellectual property of
# Saleh Ali. All rights reserved.
#
# Unauthorized modification, reproduction, redistribution, reverse engineering,
# or creation of derivative works is strictly prohibited without prior written
# approval from Saleh Ali.
#
# For full license and disclaimer details, please refer to the LICENSE.md and
# DISCLAIMER.md files in the project root.
# =============================================================================

import bcrypt
from datetime import datetime, timedelta
from typing import Any, Union
from jose import jwt
from app.core.config import settings

ALGORITHM = "HS256"

def create_access_token(
    subject: Union[str, Any], expires_delta: timedelta = None
) -> str:
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(
            minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES
        )
    to_encode = {"exp": expire, "sub": str(subject)}
    encoded_jwt = jwt.encode(to_encode, settings.SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

def verify_password(plain_password: str, hashed_password: str) -> bool:
    return bcrypt.checkpw(
        plain_password.encode('utf-8'), 
        hashed_password.encode('utf-8')
    )

def get_password_hash(password: str) -> str:
    salt = bcrypt.gensalt()
    hashed = bcrypt.hashpw(password.encode('utf-8'), salt)
    return hashed.decode('utf-8')
